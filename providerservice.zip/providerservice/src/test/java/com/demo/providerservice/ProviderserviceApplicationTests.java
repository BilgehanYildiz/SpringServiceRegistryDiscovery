package com.demo.providerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProviderserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}

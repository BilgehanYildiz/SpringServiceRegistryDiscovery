package com.demo.providerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProviderserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProviderserviceApplication.class, args);
	}

}

package com.demo.providerservice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/example")
public class ExampleController {

    @GetMapping("hello")
    public ResponseEntity helloworld()
    {
        return ResponseEntity.status(HttpStatus.OK).body("Merhaba Dünya");
    }
}

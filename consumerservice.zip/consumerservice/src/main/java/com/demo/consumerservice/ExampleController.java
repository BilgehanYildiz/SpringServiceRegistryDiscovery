package com.demo.consumerservice;

import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@RestController
@RequestMapping("api/consumer")
public class ExampleController {

    @Autowired
    private DiscoveryClient discoveryClient;

    @GetMapping("callservice")
    public ResponseEntity helloworld()
    {
        List<ServiceInstance> instanceList=this.discoveryClient.getInstances("PROVIDERSERVICE");

        String BaseUri=instanceList.get(0).getUri().toString();
        String path="/api/example/hello";
        WebClient client = WebClient.create(BaseUri+path);
        WebClient.ResponseSpec responseSpec  = client.get().retrieve();
        String responseBody = responseSpec.bodyToMono(String.class).block();
        return ResponseEntity.status(HttpStatus.OK).body("Çağırıldı"+responseBody);
    }
}
